from utils import *
# This class sefines an MDP
class MarkovDecisionProcess:
    def __init__(self, grid, terminals, actionList=orientations, gamma=0.8):
        self.actionList = actionList
        self.terminals = terminals
        self.gamma = gamma
        self.states = set()
        self.reward = {}
        self.grid = grid
        self.grid.reverse()
        self.rows = len(self.grid)
        self.columns = len(self.grid[0])
        for x in range(self.columns):
            for y in range(self.rows):
                self.reward[x, y] = self.grid[y][x]
                if self.grid[y][x] is not None:
                    self.states.add((x, y))


    def rewardForState(self, state):
        return self.reward[state]

    def getActions(self, state):
        if state in self.terminals:
            return [None]
        else:
            return self.actionList


    def transitionModel(self, state, action):
        if action is None:
            return [(0.0, (state, state, action))]
        else:
            return [(0.8, (self.go(state, action), state, action)),
                    (0.1, (self.go(state, turn_right(action)), state, action)),
                    (0.1, (self.go(state, turn_left(action)), state, action))]

    def go(self, state, direction):
        "Return the state that results from going in this direction."
        # print state, direction
        state1 = vector_add(state, direction)
        return if_(state1 in self.states, state1, state)


def valueIteration(mdp, epsilon=0.001):
    utilityDict = {}
    for state in mdp.states:
        utilityDict[state] = 0
    numberOfIterations = 0
    while True:
        previousStateUtility  = utilityDict.copy()
        difference = 0
        for state in mdp.states:
            utilityDict[state] = getPresentUtilitiesAfterIteration(mdp, previousStateUtility, state)
            difference = max(difference, abs(utilityDict[state] - previousStateUtility[state]))
        numberOfIterations += 1
        if difference < epsilon * (1 - mdp.gamma)/mdp.gamma:
            return utilityDict, numberOfIterations

def getPresentUtilitiesAfterIteration(mdp, previousStateUtility, state):
    # your code here
    # the rewardForState method returns the reward for a particular state
    # the getActions method returns the actions available at a given state
    # the transitionModel method returns a list of tuples: the first element is the transition probability and
    #  the second element the triplet (s', s, a)
    print 'state' , mdp.rewardForState(state)
    print 'actions', mdp.getActions(state)
    print 'transition model ', mdp.transitionModel(state, mdp.getActions(state)[0])
    exit("Please implement the getPresentUtilitiesAfterIteration method first ")


