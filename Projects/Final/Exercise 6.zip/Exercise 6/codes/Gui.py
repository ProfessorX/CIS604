# __author__ = 'zshoroye'
import Tkinter
from MarkovDecisionProcess import *
class simpleapp_tk(Tkinter.Tk):
    def __init__(self, parent, mdp):
        Tkinter.Tk.__init__(self, parent)
        self.parent = parent
        self.mdp = mdp
        self.initialize()

    def initialize(self):
        self.grid()
        self.columnconfigure(0, pad=30)
        self.columnconfigure(1, pad=30)
        self.columnconfigure(2, pad=30)
        self.columnconfigure(3, pad=30)

        self.rowconfigure(0, pad=30)
        self.rowconfigure(1, pad=30)
        self.rowconfigure(2, pad=30)
        self.rowconfigure(3, pad=30)
        self.rowconfigure(4, pad=30)

        self.entryVariable = Tkinter.StringVar()
        self.entry = Tkinter.Entry(self, textvariable=self.entryVariable)

        self.numberOfLabels = self.mdp.rows * self.mdp.columns
        self.labelVariables = [Tkinter.StringVar() for i in range(self.numberOfLabels)]
        self.labels = [Tkinter.Label(self, textvariable=self.labelVariables[i], anchor="w") for i in range(self.numberOfLabels)]

        labelValues = [-0.04, -0.04, -0.04, +1, -0.04, None,  -0.04, -1, -0.04, -0.04, -0.04, -0.04]

        for i in range(self.numberOfLabels):
            self.labels[i].grid(column=int(i%4), row=int(i/4))
            self.labelVariables[i].set(labelValues[i])

        button = Tkinter.Button(self, text=u"Value Iteration", command=self.OnButtonClick)
        button.grid(column=0, row=3, columnspan=2)

        labelVariable1 = Tkinter.StringVar()
        label = Tkinter.Label(self, textvariable=labelVariable1, anchor="w", fg="white", bg="blue")
        label.grid(column=0, row=4, columnspan=2, sticky='EW')
        labelVariable1.set(u"gamma = 0.8")

        self.labelVariable2 = Tkinter.StringVar()
        label = Tkinter.Label(self, textvariable=self.labelVariable2, anchor="w", fg="white", bg="blue")
        label.grid(column=0, row=5, columnspan=2, sticky='EW')
        self.labelVariable2.set(u"Number of iterations")

        # self.grid_columnconfigure(0, weight=1)
        self.resizable(False, False)
        self.update()
        self.geometry(self.geometry())
        self.entry.focus_set()
        self.entry.selection_range(0, Tkinter.END)

    def setVariablesOnValues(self, newValues):
        for i in range(self.numberOfLabels):
            self.labelVariables[i].set(str(newValues[i]))


    def OnButtonClick(self):
        values, numberOfIterations = valueIteration(self.mdp, 0.01)
        self.labelVariable2.set(u"Number of iterations: " + str(numberOfIterations))
        self.updateTheGui(values)

    def updateTheGui(self, values):
        for state in values:
            i = abs(state[1] -2) * 4 + state[0]
            self.labelVariables[i].set("{0:.2f}".format(values[state]))

if __name__ == "__main__":
    mdp = MarkovDecisionProcess([[-0.04, -0.04, -0.04, +1],
                     [-0.04, None,  -0.04, -1],
                     [-0.04, -0.04, -0.04, -0.04]],
                    terminals=[(3, 2), (3, 1)])

    app = simpleapp_tk(None, mdp)
    app.title('VALUE ITERATION')
    # app.geometry("%sx%s+%s+%s" % (500,500,500,300))
    app.pack_slaves()
    app.mainloop()